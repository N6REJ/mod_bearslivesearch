# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2025.07.18.9] - 2025-07-18

### Changed

* Update version to  [skip ci] ([68379b8](https://github.com/N6REJ/mod_bearslivesearch/commit/68379b8))
* Update mod_bearslivesearch.xml ([86df767](https://github.com/N6REJ/mod_bearslivesearch/commit/86df767))
* Update bearslivesearch.css ([623770c](https://github.com/N6REJ/mod_bearslivesearch/commit/623770c))
* Update version to  [skip ci] ([34622a1](https://github.com/N6REJ/mod_bearslivesearch/commit/34622a1))
* Update joomla-packager.yml ([32af75b](https://github.com/N6REJ/mod_bearslivesearch/commit/32af75b))

