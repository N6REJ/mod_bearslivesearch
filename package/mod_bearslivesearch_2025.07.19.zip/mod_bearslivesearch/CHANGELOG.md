# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2025.07.19] - 2025-07-19

### Changed

* Update version to  [skip ci] ([33fbd0e](https://github.com/N6REJ/mod_bearslivesearch/commit/33fbd0e))
* more package files left ([7f75ad8](https://github.com/N6REJ/mod_bearslivesearch/commit/7f75ad8))
* Update version to  [skip ci] ([3ab6ce9](https://github.com/N6REJ/mod_bearslivesearch/commit/3ab6ce9))
* more package files left ([773ed00](https://github.com/N6REJ/mod_bearslivesearch/commit/773ed00))
* Update joomla-packager.yml ([a8bdc98](https://github.com/N6REJ/mod_bearslivesearch/commit/a8bdc98))

