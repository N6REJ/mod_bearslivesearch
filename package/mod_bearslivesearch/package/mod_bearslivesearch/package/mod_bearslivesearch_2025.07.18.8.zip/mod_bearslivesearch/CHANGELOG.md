# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2025.07.18.8] - 2025-07-18

### Changed

* Update version to  [skip ci] ([7000856](https://github.com/N6REJ/mod_bearslivesearch/commit/7000856))
* missing license info and file ([8f49f8a](https://github.com/N6REJ/mod_bearslivesearch/commit/8f49f8a))
* Merge remote-tracking branch 'origin/main' ([7243e4b](https://github.com/N6REJ/mod_bearslivesearch/commit/7243e4b))
* Update version to  [skip ci] ([68379b8](https://github.com/N6REJ/mod_bearslivesearch/commit/68379b8))
* Update mod_bearslivesearch.xml ([86df767](https://github.com/N6REJ/mod_bearslivesearch/commit/86df767))
* Update bearslivesearch.css ([623770c](https://github.com/N6REJ/mod_bearslivesearch/commit/623770c))

