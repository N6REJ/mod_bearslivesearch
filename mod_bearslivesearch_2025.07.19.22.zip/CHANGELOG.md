# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2025.07.19.22] - 2025-07-19

### Changed

* Update version to  [skip ci] ([e586141](https://github.com/N6REJ/mod_bearslivesearch/commit/e586141))
* Update version to  [skip ci] ([274cb52](https://github.com/N6REJ/mod_bearslivesearch/commit/274cb52))

